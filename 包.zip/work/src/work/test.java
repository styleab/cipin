package work;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class test {
	

public static void main(String[] args) throws Exception{
	long startTime = System.currentTimeMillis();    //��ȡ��ʼʱ��
Scanner input=new Scanner(System.in);
System.out.println("������·��");
String path=input.next();
int charNum= 0 ;
int wordsNum= 0;
int lineNum = 0;
InputStreamReader isr = new InputStreamReader(new FileInputStream(path));
BufferedReader br = new BufferedReader(isr);
while( br.read()!= -1){
String s = br.readLine();
charNum+=s.length();
wordsNum +=s.split(" ").length;
lineNum ++;
}
isr.close();//�ر�
System.out.println("�ַ���:"+charNum+"\t������:"+wordsNum+"�� ��:"+lineNum);



long endTime = System.currentTimeMillis();

System.out.println("��������ʱ�䣺" + (endTime - startTime) + "ms"); 

}

public void setVisible(boolean b) {
	// TODO Auto-generated method stub
	
}




}