package work;
import java.awt.FlowLayout;
import java.awt.event.*;
 
import javax.swing.*;
 
public class MainUI extends JFrame {
     
    public MainUI() {
        this.setTitle("ѡ��");
        this.setSize(300, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(new FlowLayout());
         
        JButton button1 = new JButton("�������ַ���");
         
        // ��ͳ��ť���������ӷ�ʽ
        button1.addActionListener(new ActionListener() {
 
            @Override
            public void actionPerformed(ActionEvent arg0) {
            	test newWindow=new test();
            	newWindow.setVisible(true);
            
            	}
        });
        this.add(button1);
         
        JButton button2 = new JButton("��Ƶ");
        
        // ��ͳ��ť���������ӷ�ʽ
        button2.addActionListener(new ActionListener() {
 
            @Override
            public void actionPerformed(ActionEvent arg0) {
            	WordCont newWindow=new WordCont();
            	newWindow.setVisible(true);
            
            	}
        });
        this.add(button2);
    }
 
    public static void main(String[] args) {
         
        new MainUI().setVisible(true);
    }
}